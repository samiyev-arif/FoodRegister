import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

// Global fetch interceptor - Authorization header avtomatik qo'shish
const _originalFetch = window.fetch;
window.fetch = function(url, options = {}) {
  const token = localStorage.getItem('authToken');
  if (token) {
    options.headers = {
      ...options.headers,
      Authorization: `Bearer ${token}`
    };
  }
  // credentials: 'include' ni olib tashlab, 'omit' ga o'zgartirish (CORS bilan muammo bo'lmasligi uchun)
  if (options.credentials === 'include') {
    options.credentials = 'omit';
  }
  return _originalFetch(url, options);
};

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
