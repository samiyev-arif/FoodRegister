export const baseURL="https://otoy.hurshidbe.uz"

// https://toycha-bcknd.hurshidbe.uz

export const getToken = () => localStorage.getItem('authToken');

export const setToken = (token) => localStorage.setItem('authToken', token);

export const removeToken = () => localStorage.removeItem('authToken');

export const getAuthHeaders = () => {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
};
